See detail in memory and cpu folder.

Need libvirt-python.
