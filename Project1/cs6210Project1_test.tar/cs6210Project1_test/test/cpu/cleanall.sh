#!/bin/sh

cd testcases/1/
make clean
cd ../2/
make clean
cd ../3/
make clean
cd ../4/
make clean
cd ../5/
make clean
