#!/bin/sh

cd testcases/1/
make
cd ../2/
make
cd ../3/
make
cd ../4/
make
cd ../5/
make
