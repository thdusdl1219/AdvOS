1. 8 virtual machines, and pin all vcpu on pcpu, each vcpu has same workload.
2. __Expected outcome__: balance to each pcpu.
