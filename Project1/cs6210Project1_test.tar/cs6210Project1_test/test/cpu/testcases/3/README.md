1. 8 vcpu. Already balance mapping. Each vcpu has the same workload.
2. __Expected outcome__: no mapping change should happen. 
