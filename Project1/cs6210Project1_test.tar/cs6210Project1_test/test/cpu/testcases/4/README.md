1. 8 vcpu. Default start, each vcpu has affinity _yyyy_. Each vcpu has same workload.
2. __Expected outcome__: Can find deterministic mapping.
