1. 8 vcpu. Default start, all vcpu has affinity _yyyy_. 4 vcpu has majority workload, 4 other vcpu has less workload.
2. __Expected outcome__: balance mapping is found.  
