#!/bin/sh

cd ..
./assignfiletoallvm.py memory/testcases/
